### System details

* OS: [write here your operative system name, version, language]
* App Version: [write here the app version, or "github" if you're using latest from github]
* If Linux, Desktop Environment: [write here your desktop environment if on Linux, otherwise leave it blank]

### Expected behavior

[write here what you were expecting from an action (specified below)]

### Actual behavior

[write here what really happened]

### Step to reproduce the behavior

[write here steps to do in order to reproduce the bad behavior, so we can trace and resolve the issue quickly]
